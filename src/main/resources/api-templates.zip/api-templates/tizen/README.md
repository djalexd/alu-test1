https://github.com/Backendless/Tizen-Backendless-Geo-Service-Demo/blob/master/src/Backendless.cpp

